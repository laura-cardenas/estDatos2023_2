package com.mycompany.ejemplocolalaura;
import java.util.LinkedList;
import java.util.Queue;
/*
Laura Valentina Cardenas
*/

public class Cola<Item> {

    private Nodo<Item> primero = null, ultimo = null;
    private int tamano = 0;

    private class Nodo<Item> {
        Item elemento;
        Nodo<Item> siguiente;

        public Nodo(Item elemento) {
            this.elemento = elemento;
            this.siguiente = null;
        }
    }

    public void encolar(Item elemento) {
        Nodo<Item> nuevoNodo = new Nodo<>(elemento);
        if (ultimo != null) {
            ultimo.siguiente = nuevoNodo;
            ultimo = nuevoNodo;
        } else if (primero == null) {
            primero = nuevoNodo;
            ultimo = nuevoNodo;
        }
        tamano++;
    }

    public Item desencolar() {
        if (primero != null) {
            Item elemento = primero.elemento;
            primero = primero.siguiente;
            if (primero == null) {
                ultimo = null;
            }
            tamano--;
            return elemento;
        }
        return null;
    }

    public Item obtenerFrente() {
        if (primero != null) {
            return primero.elemento;
        }
        return null;
    }

    public boolean estaVacia() {
        return primero == null;
    }

    public int obtenerTamano() {
        return tamano;
    }

    public void mostrarCola() {
    if (estaVacia()) {
        System.out.println("La cola está vacía.");
    } else {
        Nodo<Item> temp = primero;
        int contador = 1;
        while (temp != null) {
            System.out.println("Elemento " + contador + " agregado: " + temp.elemento.toString());
            temp = temp.siguiente;
            contador++;
        }
    }
}
}


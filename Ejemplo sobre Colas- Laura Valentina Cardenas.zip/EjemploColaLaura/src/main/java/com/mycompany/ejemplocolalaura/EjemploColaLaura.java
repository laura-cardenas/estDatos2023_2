package com.mycompany.ejemplocolalaura;
import java.util.Scanner;
/*
Laura Valentina Cardenas
*/


public class EjemploColaLaura {

    public static void main(String[] args) {
        Cola<String> miCola = new Cola<>();
        Scanner teclado = new Scanner(System.in);
        
        int opcion;
        do {
            System.out.println("Menu:");
            System.out.println("1. Agregar un artículo");
            System.out.println("2. Eliminar el artículo menos reciente");
            System.out.println("3. Verificar si la cola está vacía");
            System.out.println("4. Ver el número de artículos en la cola");
            System.out.println("5. Mostrar la cola");
            System.out.println("6. Salir");
            System.out.print("Elija una opción: ");
            opcion = teclado.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del artículo a agregar: ");
                    teclado.nextLine();  
                    String nuevoArticulo = teclado.nextLine();
                    miCola.encolar(nuevoArticulo);
                    break;
                case 2:
                    String articuloEliminado = miCola.desencolar();
                    if (articuloEliminado != null) {
                        System.out.println("Se eliminó el artículo: " + articuloEliminado);
                    } else {
                        System.out.println("La cola está vacía. No se pudo eliminar ningún artículo.");
                    }
                    break;
                case 3:
                    if (miCola.estaVacia()) {
                        System.out.println("La cola está vacía.");
                    } else {
                        System.out.println("La cola no está vacía.");
                    }
                    break;
                case 4:
                    System.out.println("Número de artículos en la cola: " + miCola.obtenerTamano());
                    break;
                case 5:
                    System.out.println("Contenido de la cola:");
                    miCola.mostrarCola();
                    break;
                case 6:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        } while (opcion != 6);
        
        
    }
}
